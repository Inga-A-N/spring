package io.nology.uruguayspringintro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UruguayspringintroApplicationTests {

	@Test
	void contextLoads() {
	}

}
