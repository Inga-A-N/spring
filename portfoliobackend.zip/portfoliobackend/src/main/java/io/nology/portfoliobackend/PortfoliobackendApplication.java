package io.nology.portfoliobackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PortfoliobackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(PortfoliobackendApplication.class, args);
	}

}
