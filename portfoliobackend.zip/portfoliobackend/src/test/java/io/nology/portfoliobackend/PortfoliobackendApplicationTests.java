package io.nology.portfoliobackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PortfoliobackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
